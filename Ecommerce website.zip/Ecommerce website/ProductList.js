import React from "react";

function ProductList() {
  const products = [
    { id: 1, name: "Laptop", price: 55000 },
    { id: 2, name: "Mobile", price: 25000 },
    { id: 3, name: "Headphones", price: 3000 }
  ];

  return (
    <div style={{padding:"20px"}}>
      <h2>Products</h2>
      <div style={{display:"flex",gap:"20px"}}>
        {products.map(p => (
          <div key={p.id} style={{border:"1px solid gray",padding:"10px"}}>
            <h4>{p.name}</h4>
            <p>Price: ₹{p.price}</p>
            <button>Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductList;

import React from "react";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav style={{background:"#222",padding:"10px"}}>
      <Link style={{color:"white",marginRight:"20px"}} to="/">Home</Link>
      <Link style={{color:"white",marginRight:"20px"}} to="/cart">Cart</Link>
      <Link style={{color:"white"}} to="/login">Login</Link>
    </nav>
  );
}

export default Navbar;

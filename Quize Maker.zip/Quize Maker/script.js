let quiz = JSON.parse(localStorage.getItem("quiz")) || [];
let userAnswers = [];

// Save question
function saveQuestion() {
  const question = document.getElementById("question").value;
  const options = [
    document.getElementById("option1").value,
    document.getElementById("option2").value,
    document.getElementById("option3").value,
    document.getElementById("option4").value
  ];
  const correct = document.getElementById("correct").value;
  quiz.push({ question, options, correct });
  alert("Question added!");
  document.getElementById("quizForm").reset();
}

// Finish quiz creation
function finishQuiz() {
  localStorage.setItem("quiz", JSON.stringify(quiz));
  alert("Quiz saved successfully!");
  window.location.href = "index.html";
}

// Display quiz
if (document.getElementById("quizContainer")) {
  const container = document.getElementById("quizContainer");
  quiz.forEach((q, i) => {
    const div = document.createElement("div");
    div.innerHTML = `
      <p>${i + 1}. ${q.question}</p>
      ${q.options.map((opt, idx) => 
        `<label><input type='radio' name='q${i}' value='${idx + 1}'> ${opt}</label><br>`).join('')}
    `;
    container.appendChild(div);
  });
}

// Submit quiz
function submitQuiz() {
  let score = 0;
  quiz.forEach((q, i) => {
    const ans = document.querySelector(`input[name='q${i}']:checked`);
    if (ans && ans.value == q.correct) score++;
  });
  localStorage.setItem("score", score);
  window.location.href = "result.html";
}

// Show results
if (document.getElementById("result")) {
  const score = localStorage.getItem("score");
  document.getElementById("result").innerHTML = `
    <h3>Your Score: ${score}/${quiz.length}</h3>
  `;
}
